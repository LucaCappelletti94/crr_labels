"""Current version of package crr_labels"""
__version__ = "1.0.0"