"""Current version of package crr_labels"""
__version__ = "1.1.0"
